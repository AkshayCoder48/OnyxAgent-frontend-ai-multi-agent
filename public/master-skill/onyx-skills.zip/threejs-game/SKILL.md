---
name: threejs-game
description: Complete Three.js game production in one skill — game direction, gameplay systems, AAA graphics, in-game UI, debug/profiling, QA & release, procedural 3D generation, image generation and audio. The SKILL.md domain map routes to the 9 full domain guides in domains/ and their deep references.
---

# Three.js Game Development — the complete production skill

This ONE skill replaces the former nine separate threejs-* skills.
It covers the full production pipeline for Three.js games. The map
below lists every domain; read the domain guide you need:
`read_file skills/threejs-game/domains/<domain>.md`.

## Domain map

### threejs-3d-generator
Generate, texture, rig, animate, stylize, convert, and download 3D assets for Three.js games via the Tripo API. Use for text-to-3D, image-to-3D, game-ready GLB/FBX, characters, creatures, buildings, props, weapons, terrain, auto-rigging, animation retargeting, model texturing, voxel/LEGO stylization, and low-poly conversion. Pair with threejs-image-generator for concept and texture references first.
Full guide: `domains/threejs-3d-generator.md` — deep references under `threejs-3d-generator/`.

### threejs-aaa-graphics-builder
Upgrade Three.js games from prototype visuals to premium browser graphics: art-direction critique, procedural model building, material and texture libraries, world prop kits, shaders, VFX, lighting and render pipeline, LOD and instancing, render budgets, and a 10-category visual scorecard. Use when screenshots still look basic or the user asks for premium, AAA, high-fidelity, showcase, or less-basic graphics.
Full guide: `domains/threejs-aaa-graphics-builder.md` — deep references under `threejs-aaa-graphics-builder/`.

### threejs-audio-generator
Generate, convert, clean, and integrate audio for Three.js browser games with ElevenLabs: sound effects, looping ambience, music tracks and loops (menu, gameplay, boss, victory/defeat stingers), UI sounds, impact/weapon/vehicle audio, creature and boss stingers, announcer and dialogue TTS, voice conversion from a scratch performance, voice cleanup, audio manifests, and Web Audio integration.
Full guide: `domains/threejs-audio-generator.md` — deep references under `threejs-audio-generator/`.

### threejs-debug-profiler
Debug and profile Three.js browser games: blank canvases, render and runtime bugs, asset and audio loading, animation, resize, mobile input, plus performance profiling of draw calls, triangles, textures, memory, shader and post-processing cost, and bundle size.
Full guide: `domains/threejs-debug-profiler.md` — deep references under `threejs-debug-profiler/`.

### threejs-game-director
Entrypoint for building, upgrading, and finishing Three.js browser games. Routes work across the sibling threejs-* skills for gameplay, graphics, UI, 3D/image/audio asset generation, debugging, and release. Use for any request to build, upgrade, polish, or ship a Three.js game as a whole, at any scope from a small arcade prototype to a premium release.
Full guide: `domains/threejs-game-director.md` — deep references under `threejs-game-director/`.

### threejs-game-ui-designer
Design premium Three.js game UI: HUDs, menus, overlays, pause/win/lose screens, settings, icon controls, touch UI, typography, responsive layout, safe areas, text fit, and UI/world cohesion.
Full guide: `domains/threejs-game-ui-designer.md` — deep references under `threejs-game-ui-designer/`.

### threejs-gameplay-systems
Build and iterate playable Three.js game systems: starter scaffold, architecture, design briefs, core loops, level and encounter design, entities, input, camera, collision and physics, scoring, objectives, and game feel. Use for first playable slices, new Vite/TypeScript/Three.js setups, level/arena/track/wave/hole/puzzle design, combat encounters, difficulty tuning, and juice.
Full guide: `domains/threejs-gameplay-systems.md` — deep references under `threejs-gameplay-systems/`.

### threejs-image-generator
Generate and edit 2D image assets for Three.js games with Google's Gemini image API: concept sheets, image-to-3D inputs, texture and material references, sky and background plates, decals, logos, icons, GUI art, title and menu art, and marketing stills. Also use for direct image editing when the user supplies an image path.
Full guide: `domains/threejs-image-generator.md` — deep references under `threejs-image-generator/`.

### threejs-qa-release
Verify and release Three.js browser games: playtest QA, automated bot playtests, mobile and responsive checks, production builds, static-hosting base paths, debug gating, bundle review, screenshots, visual regression baselines, canvas-pixel inspection with measured metrics, and release risk reports.
Full guide: `domains/threejs-qa-release.md` — deep references under `threejs-qa-release/`.

## How to use
1. Identify the production phase of the task (design → systems → graphics → UI → audio → debug → QA → release).
2. Read the matching domain guide (and its references) BEFORE writing code.
3. Combine domains as needed — a gameplay task usually needs `threejs-gameplay-systems` + `threejs-debug-profiler`.
