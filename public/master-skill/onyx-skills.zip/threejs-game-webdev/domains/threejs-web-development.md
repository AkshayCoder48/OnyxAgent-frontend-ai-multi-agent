# Three.js Web Development — interactive 3D on real websites

Use this domain when the deliverable is a WEBSITE or a web FEATURE powered by
Three.js — not a game: hero sections, product showcases & configurators,
scroll-driven storytelling, 3D portfolios, data-viz scenes, particle
backgrounds. For gameplay, loops, and score, use the game domains instead.

## 1. Choose the right integration

- Tiny accent (gradient, glow, blob)? CSS/SVG first — Three.js only when it
  is genuinely 3D and interactive.
- One-off hero or product viewer on a plain site → vanilla Three.js module,
  no framework.
- React / Next.js site → `@react-three/fiber` (R3F) + `@react-three/drei`.
- Scroll story → R3F `ScrollControls` or manual scroll mapping + Lenis.
- Full-site 3D app → architect it like a game (see threejs-game-director)
  but keep every route code-split.

## 2. Project setups (pick ONE)

### Vanilla Vite + TypeScript
- `npm create vite@latest` → add `three` + `@types/three`.
- Core: `WebGLRenderer({ antialias: true, alpha: true })`, `ACESFilmicToneMapping`,
  `PerspectiveCamera(fov 45)`, resize via ResizeObserver, rAF loop with
  `clock.getDelta()`.
- Unmount hygiene: dispose geometries, materials, textures, renderer; cancel rAF.

### Next.js + React Three Fiber
- App Router: the `<Canvas>` tree is a client component — `"use client"` on
  every 3D file, `dynamic(() => import(...), { ssr: false })` at the boundary.
- `<Canvas dpr={[1, 2]} camera={{ fov: 45, position: [...] }}
  gl={{ antialias: true, alpha: true }}>`.
- drei workhorses: `Environment` (HDR lighting), `useGLTF` (+ `useGLTF.preload`),
  `ContactShadows`, `Float`, `Html`, `useScroll`/`ScrollControls`, `PerformanceMonitor`.

## 3. Scroll-driven scenes

- Map scroll progress 0..1 to camera path + scene state; LERP every frame —
  never snap.
- R3F: `ScrollControls` + `useScroll()`; vanilla: scroll listener → target
  value consumed inside the rAF loop.
- Keep copy/headings as REAL DOM (overlay divs or drei `<Html>`), not in-canvas
  text — SEO and a11y live in the DOM.
- Long timelines: GSAP ScrollTrigger or Lenis smoothing; pin sections; scrub
  (tie animation time to scroll, not to clock).

## 4. Hero sections & backgrounds

- Budget: ≤ 150k triangles, one material per draw call, ≤ 2-3 texture sets.
- Particle backgrounds: `THREE.Points` + `BufferGeometry` + `ShaderMaterial`;
  cap counts by device (mobile ≈ 40-60% of desktop), animate in the shader.
- Pause rendering when the canvas is offscreen (`IntersectionObserver`) and
  when the tab is hidden (`visibilitychange`).
- `prefers-reduced-motion`: render ONE static frame — no continuous loop.

## 5. Product showcases & configurators

- GLTF assets, DRACO or meshopt compressed; target ≤ 2MB per model on 4G.
- Lighting: drei `Environment` preset or a small HDR (polyhaven) — no baked
  point-light clusters.
- Hotspots: raycast hover/click + drei `<Html>` anchors for labels.
- Variant switching: share the geometry, swap material/color instances —
  never re-load the model per variant.
- `OrbitControls`: `enablePan={false}`, clamp `minDistance`/`maxDistance`/
  `minPolarAngle`/`maxPolarAngle` so users cannot get lost.

## 6. Web performance budget (non-negotiable)

- LCP < 2.5s: ship a poster/placeholder; fade the canvas in when assets are
  ready — the 3D layer must never block first paint.
- Code-split the 3D chunk (dynamic import); lazy-mount below-the-fold canvases.
- Cap `dpr` to [1, 2]; antialias only when dpr ≤ 1.5 (mobile GPUs).
- Compress: DRACO/meshopt for meshes, KTX2/basis for textures.
- Dispose on route change — leaked WebGL contexts kill an SPA.
- Test on throttled mid-tier mobile (CPU 4x slowdown); desktop 60fps is not
  the bar, throttled mobile is.

## 7. Responsive & accessibility

- The canvas fills a CONTAINER div (never the window); ResizeObserver →
  `camera.aspect` + `renderer.setSize`.
- Touch targets ≥ 44px; passive listeners for scroll/touch.
- Fallbacks: poster frame, `prefers-reduced-motion` static frame,
  `<noscript>` message.
- Overlay text must still pass WCAG contrast — the 3D behind it is not an
  excuse; keep overlay UI keyboard-navigable.

## 8. SEO & deployment

- Real DOM carries the content: headings, copy, links are HTML; 3D is the
  enhancement layer.
- Static export or Node server both work; models/textures live in `public/`
  with long-lived cache headers and absolute `/paths`.
- `og:image` = the poster frame, not a canvas capture.

## 9. Web vs game — route the task

- Score, input loops, physics, enemies, levels → the game domains
  (start at threejs-gameplay-systems).
- Marketing site, product page, portfolio, landing → THIS guide.
- Mixed (playable ad, configurator with mini-game) → this guide for the shell,
  game domains for the playable core.

## Ship checklist

- [ ] Poster/placeholder + fade-in on ready
- [ ] 3D chunk code-split; below-fold canvases lazy
- [ ] dpr capped, DRACO/KTX2 compression on
- [ ] Rendering paused offscreen + hidden tab
- [ ] Reduced-motion static frame
- [ ] Resize + throttled-mobile pass
- [ ] Everything disposed on unmount
- [ ] Real-DOM text for SEO; overlays keyboard-navigable
